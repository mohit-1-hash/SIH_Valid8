# Complete Permissioned Blockchain Implementation for Certificate Management
import hashlib
import json
import datetime
import csv
import uuid
from typing import List, Dict, Optional
import os

class CertificateBlockchain:
    def __init__(self):
        self.chain = []
        self.pending_certificates = []
        self.authorized_institutions = {}
        self.certificate_index = {}  # For fast searching
        self.create_genesis_block()
        
    def create_genesis_block(self):
        """Create the first block in the chain"""
        genesis_block = {
            'index': 0,
            'timestamp': str(datetime.datetime.now()),
            'certificates': [],
            'merkle_root': '0',
            'previous_hash': '0',
            'hash': self.calculate_hash({
                'index': 0,
                'timestamp': str(datetime.datetime.now()),
                'certificates': [],
                'merkle_root': '0',
                'previous_hash': '0'
            })
        }
        self.chain.append(genesis_block)
        
    def register_institution(self, institution_id: str, institution_name: str, public_key: str) -> bool:
        """Register a new institution with permission to add certificates"""
        if institution_id not in self.authorized_institutions:
            self.authorized_institutions[institution_id] = {
                'name': institution_name,
                'public_key': public_key,
                'status': 'active',
                'registered_date': str(datetime.datetime.now())
            }
            return True
        return False
    
    def is_authorized(self, institution_id: str) -> bool:
        """Check if institution is authorized to add certificates"""
        return (institution_id in self.authorized_institutions and 
                self.authorized_institutions[institution_id]['status'] == 'active')
    
    def add_certificate(self, institution_id: str, certificate_data: Dict) -> Dict:
        """Add a single certificate (for individual uploads)"""
        if not self.is_authorized(institution_id):
            return {"success": False, "message": "Institution not authorized"}
        
        # Validate certificate data
        required_fields = ['student_name', 'course_name', 'issue_date', 'certificate_type']
        if not all(field in certificate_data for field in required_fields):
            return {"success": False, "message": "Missing required certificate fields"}
        
        # Generate unique certificate ID
        certificate_id = f"CERT-{institution_id}-{uuid.uuid4().hex[:8].upper()}"
        
        certificate = {
            'certificate_id': certificate_id,
            'institution_id': institution_id,
            'institution_name': self.authorized_institutions[institution_id]['name'],
            'student_name': certificate_data['student_name'],
            'course_name': certificate_data['course_name'],
            'issue_date': certificate_data['issue_date'],
            'completion_date': certificate_data.get('completion_date', ''),
            'grade': certificate_data.get('grade', ''),
            'credits': certificate_data.get('credits', 0),
            'certificate_type': certificate_data['certificate_type'],
            'timestamp': str(datetime.datetime.now()),
            'hash': ''
        }
        
        # Calculate certificate hash
        certificate['hash'] = self.calculate_certificate_hash(certificate)
        
        # Add to pending certificates
        self.pending_certificates.append(certificate)
        
        # Add to search index
        self.update_certificate_index(certificate)
        
        return {"success": True, "certificate_id": certificate_id, "hash": certificate['hash']}
    
    def bulk_upload_certificates(self, institution_id: str, certificates_data: List[Dict]) -> Dict:
        """Upload multiple certificates in bulk"""
        if not self.is_authorized(institution_id):
            return {"success": False, "message": "Institution not authorized"}
        
        successful_uploads = []
        failed_uploads = []
        
        for cert_data in certificates_data:
            result = self.add_certificate(institution_id, cert_data)
            if result['success']:
                successful_uploads.append(result['certificate_id'])
            else:
                failed_uploads.append(cert_data.get('student_name', 'Unknown'))
        
        # Create a new block with pending certificates if we have enough
        if len(self.pending_certificates) >= 10:  # Batch size threshold
            self.create_certificate_block()
        
        return {
            "success": True,
            "uploaded": len(successful_uploads),
            "failed": len(failed_uploads),
            "successful_certificates": successful_uploads,
            "failed_certificates": failed_uploads
        }
    
    def create_certificate_block(self) -> Dict:
        """Create a new block with pending certificates using Merkle tree"""
        if not self.pending_certificates:
            return {"success": False, "message": "No pending certificates"}
        
        # Calculate Merkle root for batch verification
        certificate_hashes = [cert['hash'] for cert in self.pending_certificates]
        merkle_root = self.calculate_merkle_root(certificate_hashes)
        
        # Get previous block
        previous_block = self.chain[-1]
        
        # Create new block
        new_block = {
            'index': len(self.chain),
            'timestamp': str(datetime.datetime.now()),
            'certificates': self.pending_certificates.copy(),
            'certificate_count': len(self.pending_certificates),
            'merkle_root': merkle_root,
            'previous_hash': previous_block['hash']
        }
        
        # Calculate block hash
        new_block['hash'] = self.calculate_hash(new_block)
        
        # Add to chain
        self.chain.append(new_block)
        
        # Clear pending certificates
        self.pending_certificates = []
        
        return {
            "success": True,
            "block_index": new_block['index'],
            "certificates_added": new_block['certificate_count'],
            "merkle_root": merkle_root
        }
    
    def calculate_certificate_hash(self, certificate: Dict) -> str:
        """Calculate SHA-256 hash for a certificate"""
        cert_copy = certificate.copy()
        cert_copy.pop('hash', None)  # Remove hash field if present
        cert_string = json.dumps(cert_copy, sort_keys=True)
        return hashlib.sha256(cert_string.encode()).hexdigest()
    
    def calculate_hash(self, block: Dict) -> str:
        """Calculate SHA-256 hash for a block"""
        block_copy = block.copy()
        block_copy.pop('hash', None)  # Remove hash field if present
        block_string = json.dumps(block_copy, sort_keys=True, default=str)
        return hashlib.sha256(block_string.encode()).hexdigest()
    
    def calculate_merkle_root(self, hashes: List[str]) -> str:
        """Calculate Merkle root for batch verification"""
        if not hashes:
            return "0"
        if len(hashes) == 1:
            return hashes[0]
        
        # Ensure even number of hashes
        if len(hashes) % 2 == 1:
            hashes.append(hashes[-1])
        
        next_level = []
        for i in range(0, len(hashes), 2):
            combined = hashes[i] + hashes[i + 1]
            next_level.append(hashlib.sha256(combined.encode()).hexdigest())
        
        return self.calculate_merkle_root(next_level)
    
    def update_certificate_index(self, certificate: Dict):
        """Update search index for fast certificate lookup"""
        cert_id = certificate['certificate_id']
        student_name = certificate['student_name'].lower()
        institution = certificate['institution_id'].lower()
        course = certificate['course_name'].lower()
        
        # Index by certificate ID
        self.certificate_index[cert_id] = certificate
        
        # Index by student name
        if 'student_name' not in self.certificate_index:
            self.certificate_index['student_name'] = {}
        if student_name not in self.certificate_index['student_name']:
            self.certificate_index['student_name'][student_name] = []
        self.certificate_index['student_name'][student_name].append(cert_id)
        
        # Index by institution
        if 'institution' not in self.certificate_index:
            self.certificate_index['institution'] = {}
        if institution not in self.certificate_index['institution']:
            self.certificate_index['institution'][institution] = []
        self.certificate_index['institution'][institution].append(cert_id)
    
    def search_certificates(self, query: str, search_type: str = "all") -> List[Dict]:
        """Search certificates by various criteria"""
        results = []
        query_lower = query.lower()
        
        # Search in all blocks (including pending)
        all_certificates = self.pending_certificates.copy()
        for block in self.chain[1:]:  # Skip genesis block
            all_certificates.extend(block['certificates'])
        
        for cert in all_certificates:
            if search_type == "certificate_id" and query == cert['certificate_id']:
                results.append(cert)
            elif search_type == "student_name" and query_lower in cert['student_name'].lower():
                results.append(cert)
            elif search_type == "institution" and query_lower in cert['institution_id'].lower():
                results.append(cert)
            elif search_type == "course" and query_lower in cert['course_name'].lower():
                results.append(cert)
            elif search_type == "all":
                # Search in all fields
                if (query_lower in cert['student_name'].lower() or
                    query_lower in cert['course_name'].lower() or
                    query_lower in cert['institution_id'].lower() or
                    query == cert['certificate_id']):
                    results.append(cert)
        
        return results
    
    def verify_certificate(self, certificate_id: str) -> Dict:
        """Verify a certificate's authenticity"""
        # Find certificate
        certificate = None
        for cert in self.pending_certificates:
            if cert['certificate_id'] == certificate_id:
                certificate = cert
                break
        
        if not certificate:
            for block in self.chain[1:]:  # Skip genesis block
                for cert in block['certificates']:
                    if cert['certificate_id'] == certificate_id:
                        certificate = cert
                        break
                if certificate:
                    break
        
        if not certificate:
            return {"success": False, "message": "Certificate not found"}
        
        # Verify certificate hash
        calculated_hash = self.calculate_certificate_hash(certificate)
        hash_valid = calculated_hash == certificate['hash']
        
        # Check if institution is still authorized
        institution_valid = self.is_authorized(certificate['institution_id'])
        
        return {
            "success": True,
            "certificate_id": certificate_id,
            "valid": hash_valid and institution_valid,
            "hash_valid": hash_valid,
            "institution_valid": institution_valid,
            "certificate_data": certificate
        }
    
    def get_blockchain_stats(self) -> Dict:
        """Get blockchain statistics"""
        total_certificates = len(self.pending_certificates)
        for block in self.chain[1:]:  # Skip genesis block
            total_certificates += len(block['certificates'])
        
        return {
            "total_blocks": len(self.chain),
            "total_certificates": total_certificates,
            "pending_certificates": len(self.pending_certificates),
            "authorized_institutions": len(self.authorized_institutions),
            "chain_valid": self.is_chain_valid()
        }
    
    def is_chain_valid(self) -> bool:
        """Validate the entire blockchain"""
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i-1]
            
            # Check if current block's hash is correct
            if current_block['hash'] != self.calculate_hash(current_block):
                return False
            
            # Check if previous hash matches
            if current_block['previous_hash'] != previous_block['hash']:
                return False
        
        return True
    
    def export_certificates_csv(self, output_file: str = "certificates_export.csv"):
        """Export all certificates to CSV file"""
        all_certificates = self.pending_certificates.copy()
        for block in self.chain[1:]:  # Skip genesis block
            all_certificates.extend(block['certificates'])
        
        if not all_certificates:
            return {"success": False, "message": "No certificates to export"}
        
        fieldnames = ['certificate_id', 'institution_id', 'institution_name', 'student_name', 
                     'course_name', 'issue_date', 'completion_date', 'grade', 'credits', 
                     'certificate_type', 'timestamp', 'hash']
        
        with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            
            for cert in all_certificates:
                writer.writerow(cert)
        
        return {"success": True, "exported_count": len(all_certificates), "file": output_file}

# Example usage and testing
if __name__ == "__main__":
    # Initialize blockchain
    blockchain = CertificateBlockchain()
    
    # Register institutions
    blockchain.register_institution("TECH_UNIV_001", "Tech University", "public_key_1")
    blockchain.register_institution("BIZ_COLLEGE_002", "Business College", "public_key_2")
    
    print("✓ Blockchain initialized with institutions")
    print(f"✓ Authorized institutions: {list(blockchain.authorized_institutions.keys())}")
    
    # Add some sample certificates
    sample_certificates = [
        {
            'student_name': 'John Doe',
            'course_name': 'Master of Computer Science',
            'issue_date': '2025-01-15',
            'completion_date': '2024-12-20',
            'grade': 'A',
            'credits': 120,
            'certificate_type': 'degree'
        },
        {
            'student_name': 'Jane Smith',
            'course_name': 'Bachelor of Business Administration',
            'issue_date': '2025-02-01',
            'completion_date': '2024-11-30',
            'grade': 'B+',
            'credits': 180,
            'certificate_type': 'degree'
        },
        {
            'student_name': 'Mike Johnson',
            'course_name': 'Python Programming Certificate',
            'issue_date': '2025-01-20',
            'certificate_type': 'certificate'
        }
    ]
    
    # Bulk upload certificates
    result = blockchain.bulk_upload_certificates("TECH_UNIV_001", sample_certificates[:2])
    print(f"✓ Bulk upload result: {result}")
    
    # Add individual certificate
    single_result = blockchain.add_certificate("BIZ_COLLEGE_002", sample_certificates[2])
    print(f"✓ Single certificate added: {single_result}")
    
    # Create block with pending certificates
    block_result = blockchain.create_certificate_block()
    print(f"✓ Block created: {block_result}")
    
    # Search certificates
    search_results = blockchain.search_certificates("John", "student_name")
    print(f"✓ Search results for 'John': {len(search_results)} certificates found")
    
    # Verify a certificate
    if search_results:
        cert_id = search_results[0]['certificate_id']
        verification = blockchain.verify_certificate(cert_id)
        print(f"✓ Certificate verification: {verification['valid']}")
    
    # Get blockchain stats
    stats = blockchain.get_blockchain_stats()
    print(f"✓ Blockchain stats: {stats}")
    
    # Export certificates to CSV
    export_result = blockchain.export_certificates_csv()
    print(f"✓ Export result: {export_result}")