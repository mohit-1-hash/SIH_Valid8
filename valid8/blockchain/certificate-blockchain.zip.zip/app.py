
from flask import Flask, request, jsonify, render_template, send_file
from flask_cors import CORS
import json
import csv
import io
from certificate_blockchain import CertificateBlockchain

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Initialize blockchain
blockchain = CertificateBlockchain()

# Register default institutions
blockchain.register_institution("TECH_UNIV_001", "Tech University", "public_key_1")
blockchain.register_institution("BIZ_COLLEGE_002", "Business College", "public_key_2")
blockchain.register_institution("MED_SCHOOL_003", "Medical School", "public_key_3")

@app.route('/')
def index():
    """Main dashboard"""
    stats = blockchain.get_blockchain_stats()
    return render_template('index.html', stats=stats)

@app.route('/api/institutions', methods=['GET'])
def get_institutions():
    """Get all authorized institutions"""
    return jsonify({
        "success": True,
        "institutions": blockchain.authorized_institutions
    })

@app.route('/api/institutions', methods=['POST'])
def register_institution():
    """Register a new institution"""
    data = request.get_json()

    required_fields = ['institution_id', 'institution_name', 'public_key']
    if not all(field in data for field in required_fields):
        return jsonify({"success": False, "message": "Missing required fields"}), 400

    success = blockchain.register_institution(
        data['institution_id'],
        data['institution_name'],
        data['public_key']
    )

    if success:
        return jsonify({"success": True, "message": "Institution registered successfully"})
    else:
        return jsonify({"success": False, "message": "Institution already exists"}), 400

@app.route('/api/certificates', methods=['POST'])
def add_certificate():
    """Add a single certificate"""
    data = request.get_json()

    if 'institution_id' not in data:
        return jsonify({"success": False, "message": "Institution ID required"}), 400

    institution_id = data.pop('institution_id')
    result = blockchain.add_certificate(institution_id, data)

    if result['success']:
        return jsonify(result)
    else:
        return jsonify(result), 400

@app.route('/api/certificates/bulk', methods=['POST'])
def bulk_upload_certificates():
    """Bulk upload certificates via JSON"""
    data = request.get_json()

    if 'institution_id' not in data or 'certificates' not in data:
        return jsonify({"success": False, "message": "Institution ID and certificates required"}), 400

    result = blockchain.bulk_upload_certificates(data['institution_id'], data['certificates'])
    return jsonify(result)

@app.route('/api/certificates/upload-csv', methods=['POST'])
def upload_csv():
    """Bulk upload certificates via CSV file"""
    if 'file' not in request.files:
        return jsonify({"success": False, "message": "No file provided"}), 400

    file = request.files['file']
    institution_id = request.form.get('institution_id')

    if not institution_id:
        return jsonify({"success": False, "message": "Institution ID required"}), 400

    if file.filename == '':
        return jsonify({"success": False, "message": "No file selected"}), 400

    if not file.filename.endswith('.csv'):
        return jsonify({"success": False, "message": "File must be CSV format"}), 400

    try:
        # Read CSV file
        stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
        csv_input = csv.DictReader(stream)
        certificates = []

        for row in csv_input:
            # Clean up the row data
            cert_data = {k.strip(): v.strip() for k, v in row.items() if v.strip()}
            if cert_data:  # Only add non-empty rows
                certificates.append(cert_data)

        if not certificates:
            return jsonify({"success": False, "message": "No valid certificate data found in CSV"}), 400

        # Upload certificates
        result = blockchain.bulk_upload_certificates(institution_id, certificates)
        return jsonify(result)

    except Exception as e:
        return jsonify({"success": False, "message": f"Error processing CSV: {str(e)}"}), 400

@app.route('/api/certificates/search', methods=['GET'])
def search_certificates():
    """Search certificates"""
    query = request.args.get('query', '')
    search_type = request.args.get('type', 'all')

    if not query:
        return jsonify({"success": False, "message": "Search query required"}), 400

    results = blockchain.search_certificates(query, search_type)
    return jsonify({
        "success": True,
        "results": results,
        "count": len(results)
    })

@app.route('/api/certificates/verify/<certificate_id>', methods=['GET'])
def verify_certificate(certificate_id):
    """Verify a specific certificate"""
    result = blockchain.verify_certificate(certificate_id)
    return jsonify(result)

@app.route('/api/blocks', methods=['POST'])
def create_block():
    """Manually create a new block with pending certificates"""
    result = blockchain.create_certificate_block()
    return jsonify(result)

@app.route('/api/blockchain', methods=['GET'])
def get_blockchain():
    """Get the entire blockchain"""
    return jsonify({
        "success": True,
        "chain": blockchain.chain,
        "length": len(blockchain.chain)
    })

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get blockchain statistics"""
    return jsonify(blockchain.get_blockchain_stats())

@app.route('/api/certificates/export', methods=['GET'])
def export_certificates():
    """Export all certificates to CSV"""
    result = blockchain.export_certificates_csv("temp_export.csv")

    if result['success']:
        return send_file("temp_export.csv", 
                        as_attachment=True, 
                        download_name="certificates_export.csv",
                        mimetype='text/csv')
    else:
        return jsonify(result), 400

@app.route('/api/validate', methods=['GET'])
def validate_chain():
    """Validate the blockchain integrity"""
    is_valid = blockchain.is_chain_valid()
    return jsonify({
        "success": True,
        "valid": is_valid,
        "message": "Blockchain is valid" if is_valid else "Blockchain is invalid"
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
